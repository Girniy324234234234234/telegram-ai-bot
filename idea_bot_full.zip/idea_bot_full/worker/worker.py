
import json, redis, os
from openai import OpenAI

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
r = redis.Redis(host="redis", port=6379, decode_responses=True)

print("Worker online")

while True:
    task = r.brpop("tasks")
    _, data = task
    job = json.loads(data)

    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role":"user","content":job["prompt"]}]
    )

    r.lpush(f"result:{job['chat']}", res.choices[0].message.content)
