import os
from dotenv import load_dotenv

# Абсолютный путь к .env в корне проекта
dotenv_path = os.path.join(os.path.dirname(__file__), "..", ".env")
load_dotenv(dotenv_path)

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
if not BOT_TOKEN:
    raise RuntimeError("❌ TELEGRAM_BOT_TOKEN не найден. Проверь файл .env")

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
if not OPENAI_API_KEY:
    raise RuntimeError("❌ OPENAI_API_KEY не найден. Проверь файл .env")

DB_URL = os.getenv("DB_URL", "postgresql://idea:idea@db:5432/idea")
REDIS_URL = os.getenv("REDIS_URL", "redis://redis:6379")
