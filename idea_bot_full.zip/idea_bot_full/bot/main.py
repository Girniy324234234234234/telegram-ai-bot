import asyncio

from aiogram import Bot, Dispatcher, F, types
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from bot.config import BOT_TOKEN


# ---------- FSM ----------
class Survey(StatesGroup):
    mood = State()
    time = State()
    interests = State()
    limits = State()


# ---------- bot / dispatcher ----------
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())


# ---------- handlers ----------
@dp.message(F.text == "/start")
async def start(message: types.Message, state: FSMContext):
    await message.answer("Настроим профиль. Какое настроение?")
    await state.set_state(Survey.mood)


@dp.message(Survey.mood)
async def step_mood(message: types.Message, state: FSMContext):
    await state.update_data(mood=message.text)
    await message.answer("Сколько у тебя времени?")
    await state.set_state(Survey.time)


@dp.message(Survey.time)
async def step_time(message: types.Message, state: FSMContext):
    await state.update_data(time=message.text)
    await message.answer("Интересы?")
    await state.set_state(Survey.interests)


@dp.message(Survey.interests)
async def step_interests(message: types.Message, state: FSMContext):
    await state.update_data(interests=message.text)
    await message.answer("Ограничения?")
    await state.set_state(Survey.limits)


@dp.message(Survey.limits)
async def step_limits(message: types.Message, state: FSMContext):
    data = await state.update_data(limits=message.text)
    await state.clear()

    # временно просто выводим данные
    text = (
        "Профиль сохранён:\n\n"
        f"Настроение: {data['mood']}\n"
        f"Время: {data['time']}\n"
        f"Интересы: {data['interests']}\n"
        f"Ограничения: {data['limits']}"
    )

    await message.answer(text)


# ---------- main ----------
async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())

