
import asyncpg
from bot.config import DB_URL

async def pool():
    return await asyncpg.create_pool(DB_URL)

CREATE = '''
CREATE TABLE IF NOT EXISTS users(
  id SERIAL PRIMARY KEY,
  tg BIGINT UNIQUE,
  profile JSONB
);
CREATE TABLE IF NOT EXISTS ideas(
  id SERIAL PRIMARY KEY,
  tg BIGINT,
  title TEXT,
  text TEXT
);
'''
