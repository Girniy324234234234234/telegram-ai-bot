
from aiogram.fsm.state import State, StatesGroup

class Survey(StatesGroup):
    mood = State()
    time = State()
    interests = State()
    limits = State()
