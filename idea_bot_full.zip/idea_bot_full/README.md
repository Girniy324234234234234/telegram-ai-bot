
# Idea Generator Bot (FULL)

## Запуск
1. Создай .env:
BOT_TOKEN=xxx
OPENAI_API_KEY=xxx

2. Запуск:
docker compose up --build

Бот + Worker + Redis + Postgres запускаются автоматически.
